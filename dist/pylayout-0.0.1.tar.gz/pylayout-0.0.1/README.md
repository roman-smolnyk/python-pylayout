# pylayout

Python module to get/set keyboard layout